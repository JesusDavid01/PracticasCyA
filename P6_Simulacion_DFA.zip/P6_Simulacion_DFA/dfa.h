// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 2: Símbolos, alfabetos y cadenas
// Autor: Jesús David Suárez Baute
// Correo: alu0101345482@ull.edu.es
// Fecha: 10/11/2021
// Archivo dfa.h: Archivo dfa.h
//        Contiene la definición de la clase Dfa y sus métodos
// Referencias:
//        https://stackoverflow.com/
// Historial de revisiones
//        10/11/2021 - Creación (primera versión) del código

#ifndef DFA_H
#define DFA_H

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <string>

#include "cadenas.h"

const int size {20};
const int Zero {0};

class Dfa {
 public:
  Dfa(std::string dfa, std::vector<Simbolo> cadena);

  unsigned int get_estado_actual();
  unsigned int get_estado_arranque();

  void set_estado_arranque(unsigned int estado_arranque);
  void set_estado_actual(unsigned int estado_actual);
  void set_numero_estados(unsigned int numero_estados);
  void set_estado(unsigned int num_estado);

  void make_estados(std::string estados, int num_estado);
  bool isNumber(std::string aux);
  bool isAccepted(std::vector<Simbolo> chain);
  int isAllOk();
  void printdfa();

 private:
  unsigned int estado_actual_;
  unsigned int numero_estados_;
  unsigned int estado_arranque_;
  int num_aceptacion;
  int num_transiciones;
  std::vector<Simbolo> estados_;
  std::ifstream dfa_file_;
  int nombre_estado_[size];
  bool aceptacion_[size];
  int transiciones_[size];
  std::string whatsimbolo_[size][size];
  int whattransicion_[size][size];
};
#endif