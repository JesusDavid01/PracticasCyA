// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 2: Símbolos, alfabetos y cadenas
// Autor: Jesús David Suárez Baute
// Correo: alu0101345482@ull.edu.es
// Fecha: 10/11/2021
// Archivo dfa.cc: Archivo dfa.cc
//        Contiene la implementación de la clase Dfa y sus métodos, además
//        de la definición del constructor
// Referencias:
//        https://stackoverflow.com/
// Historial de revisiones
//        10/11/2021 - Creación (primera versión) del código

#include "dfa.h"

Dfa::Dfa(std::string dfa_file, std::vector<Simbolo> chain) {
  dfa_file_.open(dfa_file);

  std::string aux;
  getline(dfa_file_, aux);
  unsigned int auxiliar = stoi(aux, nullptr);
  set_numero_estados(auxiliar);
  aux = "";

  getline(dfa_file_, aux);
  auxiliar = stoi(aux, nullptr);
  set_estado_arranque(auxiliar);
  aux = "";

  int num_estado {0};
  while(getline(dfa_file_, aux, '\n')) {
    make_estados(aux, num_estado);
  }
  isAllOk();
  estado_actual_ = estado_arranque_;
  isAccepted(chain);
}

void Dfa::set_estado_arranque(unsigned int estado_arranque) {
  estado_arranque_ = estado_arranque;
}

void Dfa::set_estado_actual(unsigned int estado_actual) {
  estado_actual_ = estado_actual;
}

void Dfa::set_numero_estados(unsigned int numero_estados) {
  numero_estados_ = numero_estados;
}

void Dfa::make_estados(std::string estados, int num_estado) {
  int transicion {0};
  std::vector<Simbolo> line_dfa;
  std::string aux;
  std::istringstream line{estados};
  while(getline(line, aux, ' ')){
    line_dfa.emplace_back(Simbolo(aux));
  }
  for (size_t i = 0; i < line_dfa.size(); i++) {
    switch (i) {
      case 0:
        num_estado = stoi(line_dfa[i].Get_Symbol());
        nombre_estado_[num_estado] = stoi(line_dfa[i].Get_Symbol());
        break;

      case 1:
        if (stoi(line_dfa[i].Get_Symbol()) == 0) {
          aceptacion_[num_estado] = false;
        } else {
          aceptacion_[num_estado] = true;
        }
        break;

      case 2:
        transiciones_[num_estado] = stoi(line_dfa[i].Get_Symbol(), nullptr);
        break;

      default:
        if (!isNumber(line_dfa[i].Get_Symbol())) {
          whatsimbolo_[num_estado][transicion] = line_dfa[i].Get_Symbol();
          whattransicion_[num_estado][transicion] = stoi(line_dfa[i + 1].Get_Symbol());
          transicion++;
        }
        break;
    }
  }
  num_transiciones = transicion;
}

bool Dfa::isNumber(std::string aux) {
  for (char c : aux) {
    if(std::isdigit(c) == 0) return false;
  }
  return true;
}

void Dfa::printdfa() {
  for (size_t i = 0; i < numero_estados_; i++) {
    for (int j = 0; j < num_transiciones ; j++) {
      std::cout << "Estado: " << nombre_estado_[i] << std::endl;
      std::cout << "Aceptacion: " << aceptacion_[i] << std::endl;
      std::cout << "Transiciones: " << transiciones_[i] << std::endl;
      std::cout << "Simbolo: " << whatsimbolo_[i][j] << " Siguiente estado: " << whattransicion_[i][j] << std::endl;
      std::cout << std::endl;
    }
  }
}

int Dfa::isAllOk() {
   for (size_t i = 0; i < numero_estados_; i++) {
    for (int j = i+1; j < num_transiciones ; j++) {
      if (nombre_estado_[i] == nombre_estado_ [j] ||
      whatsimbolo_[i][i] == whatsimbolo_[i][j]) {
        std::cout << "ERROR. HAY MAS DE UN SIMBOLO IGUAL. SOLO SE PERMITE UNA"
        "TRANSICION POR SIMBOLO" << std::endl;
        return 0;
      } 
    }
  }
  return 1;
}

bool Dfa::isAccepted(std::vector<Simbolo> chain) {
  for(size_t i = 0; i < chain.size(); i++) {
  int contador {0};
    while(contador != num_transiciones) {
      if (chain[i].Get_Symbol() == whatsimbolo_[estado_actual_][contador]) {
        estado_actual_ = whattransicion_[estado_actual_][contador];
        contador++;
      } else {
        contador++;
      }
    }
  }
  if (aceptacion_[estado_actual_] == 1) {
    return true; 
  } else {
    return false;
  }
}